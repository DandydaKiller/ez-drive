# JavaCalendar
CS151 Summer group project to develop a GUI based Calendar. 
